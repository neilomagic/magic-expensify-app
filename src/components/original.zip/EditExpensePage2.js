import React from 'react';
import {connect} from 'react-redux';

const EditExpensePage = (props)=>{
    console.log(props);
    return
    (
    <div>
    This is from my Edit page!!
    
    </div>
    
);
};

export default connect()(EditExpensePage);