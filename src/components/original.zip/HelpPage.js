import React from 'react';

const HelpPage = ()=>(
    <div>
    This is from my Help page
    </div>
);

export default HelpPage